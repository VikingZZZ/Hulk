namespace Hulk;
using System;

public class Procesing
{
    public static void Print(string expression)
    {
        string value = "";
        List<char> list = new List<char>();
        if (expression.Contains("(") && expression.Contains(")") && expression.Contains(";") && expression.Contains('"'))
        {
            for (int i = 6; i < expression.Length-1; i++)
            {
                list.Add(expression[i]);

            }   
            char[] array = list.Toarray();
            value = String.Join("",array);         
        }
        else if (expression.Contains('(') && expression.Contains(")") && expression.Contains(";") && expression.Contains('"'))
        {
            for (int i = 6; i < expression.Length-2; i++)
            {
                list.Add(expression[i]);

            }   
            char[] array = list.Toarray();
            value = String.Join("",array); 
        else if (expression.Contains('(') && expression.Contains(")") && expression.Contains(";") && expression.Contains('"'))
        {
            for (int i = 6; i < expression.Length-3; i++)
            {
                list.Add(expression[i]);

            }   
            char[] array = list.Toarray();
            value = String.Join("",array);
        }
        else
        {
            Console.Writeline("Syntaxis Error")
        }
        Console.Writeline(value);
    }
}