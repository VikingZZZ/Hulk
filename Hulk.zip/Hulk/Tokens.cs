namespace Hulk;
using System;

public class Tokens
{
    public List<string> keyWords = new list<string>{"print", "let", "in", "if", "else", "(", ")", ";", "=", "+", "-", "*", "/", "=="}
}